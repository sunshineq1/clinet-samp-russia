#include "../main.h"
#include "game.h"
#include "../net/netgame.h"
#include "vehicle.h"
#include "Streaming.h"
#include "../game/Entity/Automobile.h"
#include "game/Entity/CBike.h"
#include "game/Entity/CTrain.h"
#include "game/Entity/CPlane.h"

extern CGame* pGame;
extern CNetGame* pNetGame;

bool bInProcessDetachTrailer = false;

CVehicle::CVehicle(int iType, float fX, float fY, float fZ, float fRotation, bool bPreloaded, bool bSiren)
{
	RwMatrix matEnt;
	static CVehicleGTA* pCreatedTrain = nullptr;

	m_pVehicle = nullptr;
	m_dwGTAId = 0;
	m_pTrailer = nullptr;

	if ((iType != TRAIN_PASSENGER_LOCO) &&
		(iType != TRAIN_FREIGHT_LOCO) &&
		(iType != TRAIN_PASSENGER) &&
		(iType != TRAIN_FREIGHT) &&
		(iType != TRAIN_TRAM)) {

        if (!CStreaming::TryLoadModel(iType))
            throw std::runtime_error("Model not loaded");

		ScriptCommand(&create_car, iType, fX, fY, fZ, &m_dwGTAId);
		ScriptCommand(&set_car_z_angle, m_dwGTAId, fRotation);
		ScriptCommand(&car_gas_tank_explosion, m_dwGTAId, 0);
		ScriptCommand(&set_car_hydraulics, m_dwGTAId, 0);
		ScriptCommand(&toggle_car_tires_vulnerable, m_dwGTAId, 0);

		m_pVehicle = GamePool_Vehicle_GetAt(m_dwGTAId);

		if (m_pVehicle) 
		{
            m_pVehicle->m_pVehicleMP = this;

			m_pVehicle->m_nDoorLock = (eCarLock)0;
			m_bIsLocked = false;

			m_pVehicle->GetMatrix(&matEnt);
			matEnt.pos.x = fX;
			matEnt.pos.y = fY;
			matEnt.pos.z = fZ;

			if( GetVehicleSubtype() != VEHICLE_SUBTYPE_BIKE &&
				GetVehicleSubtype() != VEHICLE_SUBTYPE_PUSHBIKE)
				matEnt.pos.z += 0.25f;

			m_pVehicle->SetMatrix((CMatrix&)matEnt);
			m_bPreloaded = bPreloaded;
		}
	}
	else if ((iType == TRAIN_PASSENGER_LOCO) ||
		(iType == TRAIN_FREIGHT_LOCO) ||
		(iType == TRAIN_TRAM))
	{
		if (iType == TRAIN_PASSENGER_LOCO) iType = 5;
		else if (iType == TRAIN_FREIGHT_LOCO) iType = 3;
		else if (iType == TRAIN_TRAM) iType = 9;

		uint32_t dwDirection = 0;
		if (fRotation > 180.0f) {
			dwDirection = 1;
		}

        if (!CStreaming::TryLoadModel(TRAIN_PASSENGER_LOCO))
            throw std::runtime_error("Model not loaded");

        if (!CStreaming::TryLoadModel(TRAIN_PASSENGER))
            throw std::runtime_error("Model not loaded");

        if (!CStreaming::TryLoadModel(TRAIN_FREIGHT_LOCO))
            throw std::runtime_error("Model not loaded");

        if (!CStreaming::TryLoadModel(TRAIN_FREIGHT))
            throw std::runtime_error("Model not loaded");
        if (!CStreaming::TryLoadModel(TRAIN_TRAM))
            throw std::runtime_error("Model not loaded");

		ScriptCommand(&create_train, iType, fX, fY, fZ, dwDirection, &m_dwGTAId);
		m_pVehicle = GamePool_Vehicle_GetAt(m_dwGTAId);

		pCreatedTrain = m_pVehicle;

		GamePrepareTrain(m_pVehicle);
	}
	else if ((iType == TRAIN_PASSENGER) ||
		(iType == TRAIN_FREIGHT))
	{
		if (!pCreatedTrain)
		{
			m_pVehicle = nullptr;
			return;
		}

		m_dwGTAId = GamePool_Vehicle_GetIndex(m_pVehicle);
		pCreatedTrain = m_pVehicle;
	}

	m_bIsInvulnerable = false;
	m_byteObjectiveVehicle = 0;
	m_bSpecialMarkerEnabled = false;
	m_dwMarkerID = 0;
	m_iEngineState = -1;
	m_bDoorsLocked = false;
	m_bHaveColor = false;
	m_bHasBeenDriven = false;
	m_dwTimeSinceLastDriven = GetTickCount();

	memset(m_szPlateText, 0, sizeof(m_szPlateText));
}

CVehicle::~CVehicle()
{
	m_pVehicle = GamePool_Vehicle_GetAt(m_dwGTAId);

	if (m_pVehicle) {
        auto modelId = m_pVehicle->m_nModelIndex;
		if(m_dwMarkerID)
		{
			pGame->DisableMarker(m_dwMarkerID);
			m_dwMarkerID = 0;
		}

        m_pVehicle->m_pVehicleMP = nullptr;

		RemoveEveryoneFromVehicle();

		if(SirenEnabled()) EnableSiren(false);

		if (m_pTrailer) {
			DetachTrailer();
			m_pTrailer = nullptr;
		}

		int iModel = m_pVehicle->m_nModelIndex;
		if (iModel == 538 || iModel == 537)
		{
			ScriptCommand(&destroy_train, m_dwGTAId);
		}
		else
		{
			ScriptCommand(&destroy_car, m_dwGTAId);
		}

        if(pPlateTexture) {
            RwTextureDestroy(pPlateTexture);
            pPlateTexture = nullptr;
        }
        if(m_pVinylTex) {
            RwTextureDestroy(m_pVinylTex);
            m_pVinylTex = nullptr;
        }

        CStreaming::RemoveModelIfNoRefs(modelId);
	}
}

eTurnState CVehicle::GetTurnLightsState() const
{
    return m_iTurnState;
}

void CVehicle::SetTurnLightsState(eTurnState state)
{
    if (m_iTurnState != state) {
        m_nTurnStateTime = CTimer::m_snTimeInMilliseconds;
    }
    m_iTurnState = state;
}

bool CVehicle::IsTurnBlinkOn() const
{
    return ((CTimer::m_snTimeInMilliseconds - m_nTurnStateTime) / 500) % 2 == 0;
}

eTurnState CVehicle::GetTurnLightsBlinkState() const
{
    return IsTurnBlinkOn() ? m_iTurnState : eTurnState::TURN_OFF;
}

void CVehicle::RenderTurnLights()
{
    if (IsTurnBlinkOn())
	{
        if (m_iTurnState == eTurnState::TURN_RIGHT)
		{
            DrawRightTurnLight();
        }
		else if (m_iTurnState == eTurnState::TURN_LEFT)
		{
            DrawLeftTurnLight();
        }
		else if (m_iTurnState == eTurnState::TURN_ALL)
		{
            DrawLeftTurnLight();
            DrawRightTurnLight();
        }
		else
		{
            m_iTurnState = eTurnState::TURN_OFF;
        }
    }
}

void CVehicle::DrawRightTurnLight()
{
    DrawTurnlight(false);
}

void CVehicle::DrawLeftTurnLight()
{
    DrawTurnlight(true);
}

#include "Coronas.h"
#include "Models/ModelInfo.h"
#include "Shadows.h"
#include "util/CUtil.h"

void CVehicle::DrawTurnlightPool(const CVector& vecObjOffset, bool bRear, int32 id)
{
    static RwTexture* pTurnLightTex = nullptr;
    static bool bTextureChecked = false;

    if (!bTextureChecked) {
        bTextureChecked = true;
        pTurnLightTex = CUtil::LoadTextureFromDB("txd", "headlight1");
    }

    if (!pTurnLightTex || !m_pVehicle) {
        return;
    }

    CMatrix& mat = m_pVehicle->GetMatrix();

    constexpr float kAwayForward = 0.48f;
    constexpr float kAwaySide    = 0.17f;

    CVector vecLightPos = vecObjOffset;
    vecLightPos.y += bRear ? -kAwayForward : kAwayForward;
    vecLightPos.x += (vecLightPos.x < 0.0f) ? -kAwaySide : kAwaySide;

    CVector vecWorld;
    ProjectMatrix(&vecWorld, &mat, &vecLightPos);

    const CVector& vecForward = mat.GetForward();
    float fwdX = vecForward.x;
    float fwdY = vecForward.y;

    const float fwdLen = sqrtf(fwdX * fwdX + fwdY * fwdY);
    if (fwdLen < 0.001f) {
        return;
    }
    fwdX /= fwdLen;
    fwdY /= fwdLen;

    if (bRear) {
        fwdX = -fwdX;
        fwdY = -fwdY;
    }

    constexpr float kPoolSize = 0.60f;

    const float frontX = fwdX * kPoolSize;
    const float frontY = fwdY * kPoolSize;
    const float sideX  = fwdY * kPoolSize * 0.7f;
    const float sideY  = -fwdX * kPoolSize * 0.7f;

    vecWorld.z += 2.0f;

    CShadows::StoreCarLightShadow(
            m_pVehicle, id, pTurnLightTex, &vecWorld,
            frontX, frontY,
            sideX, sideY,
            150, 150, 0,
            7.0f, true);
}

void CVehicle::DrawTurnlight(bool leftSide)
{
    auto pModelInfoStart = CModelInfo::GetVehicleModelInfo(m_pVehicle->m_nModelIndex);
    CVector* m_avDummyPos = pModelInfoStart->m_pVehicleStruct->m_avDummyPos;

    CVector vecFront;
    auto frontOffsetX = m_avDummyPos[0].x + 0.1f;
    vecFront.x = leftSide ? -frontOffsetX : frontOffsetX;
    vecFront.y = m_avDummyPos[0].y;
    vecFront.z = m_avDummyPos[0].z;

    CVector vecRear;
    auto rearOffsetX = m_avDummyPos[1].x + 0.1f;
    vecRear.x = leftSide ? -rearOffsetX : rearOffsetX;
    vecRear.y = m_avDummyPos[1].y;
    vecRear.z = m_avDummyPos[1].z;

    CRGBA turnSignalColor(255, 180, 0, 255);
    CCoronas::RegisterCorona(
            m_dwGTAId + reinterpret_cast<std::uintptr_t>(m_avDummyPos) + leftSide + 0,
            m_pVehicle,
            turnSignalColor.r, turnSignalColor.g, turnSignalColor.b, turnSignalColor.a,
            &vecFront,
            0.3f,
            40.0f,
            eCoronaType::CORONATYPE_SHINYSTAR,
            eCoronaFlareType::FLARETYPE_NONE,
            false,
            false,
            0,
            0.f,
            false,
            0.5,
            0,
            50.0f,
            false,
            true
    );
    CCoronas::RegisterCorona(
            m_dwGTAId + reinterpret_cast<std::uintptr_t>(m_avDummyPos) + leftSide + 2,
            m_pVehicle,
            turnSignalColor.r, turnSignalColor.g, turnSignalColor.b, turnSignalColor.a,
            &vecRear,
            0.3f,
            40.0f,
            eCoronaType::CORONATYPE_SHINYSTAR,
            eCoronaFlareType::FLARETYPE_NONE,
            false,
            false,
            0,
            0.f,
            false,
            0.5,
            0,
            50.0f,
            false,
            true
    );

    DrawTurnlightPool(vecFront, false, (int32)(m_dwGTAId * 4 + leftSide));
    DrawTurnlightPool(vecRear,  true,  (int32)(m_dwGTAId * 4 + leftSide + 2));
}

// 0.3.7
bool CVehicle::IsRCVehicle()
{
	if (m_pVehicle)
	{
		if (GamePool_Vehicle_GetAt(m_dwGTAId))
		{
			int iModel = m_pVehicle->m_nModelIndex;
			if (iModel == 441
				|| iModel == 464
				|| iModel == 465
				|| iModel == 594
				|| iModel == 501
				|| iModel == 564) {
				return true;
			}
		}
	}

	return false;
}
// 0.3.7
float CVehicle::GetHealth()
{
	if (m_pVehicle) {
		return m_pVehicle->fHealth;
	}

	return 0.0f;
}
// 0.3.7
void CVehicle::SetHealth(float fHealth)
{
	if (m_pVehicle) {
		m_pVehicle->fHealth = fHealth;
	}
}
// 0.3.7
int CVehicle::GetVehicleSubtype()
{
	if (m_pVehicle) {
		return ::GetVehicleSubtype(m_pVehicle);
	}

	return 0;
}
// 0.3.7
void CVehicle::AddComponent(int iComponentID)
{
	if (!m_pVehicle || !GamePool_Vehicle_GetAt(m_dwGTAId)) return;
	if (GetVehicleSubtype() != VEHICLE_SUBTYPE_CAR) return;

    if(!CStreaming::GetInfo(iComponentID).IsLoaded()) {
        //CStreaming::RequestModel(iComponentID, STREAMING_GAME_REQUIRED | STREAMING_KEEP_IN_MEMORY);
        CHook::CallFunction<void>("_ZN10CStreaming21RequestVehicleUpgradeEii", iComponentID, 10);
        CStreaming::LoadAllRequestedModels(false);
        uint32 count = 0;
        while (!CStreaming::GetInfo(iComponentID).IsLoaded()) {
            count++;
            std::this_thread::sleep_for(std::chrono::milliseconds(100));

            if (count > 30) {
                //pUI->chat()->addDebugMessage("{ff0000} Error loading model %d", iComponentID);
                return;
            }
        }
    }

	uint32_t dwRet;
	ScriptCommand(&add_car_component, m_dwGTAId, iComponentID, &dwRet);
}
// 0.3.7
void CVehicle::SetPaintJob(uint8_t bytePaintJobID)
{
    if(!GamePool_Vehicle_GetAt(m_dwGTAId) || bytePaintJobID < 0)
        return;

    ScriptCommand(&change_car_skin, m_dwGTAId, bytePaintJobID);
}
// 0.3.7
void CVehicle::SetColor(uint8_t byteColor1, uint8_t byteColor2)
{
	if (m_pVehicle && GamePool_Vehicle_GetAt(m_dwGTAId))
	{
		m_pVehicle->m_nPrimaryColor = byteColor1;
		m_pVehicle->m_nSecondaryColor = byteColor2;
	}

	m_byteColor1 = byteColor1;
	m_byteColor2 = byteColor2;
	m_bHaveColor = true;
}
// 0.3.7
void CVehicle::DetachTrailer()
{
	bInProcessDetachTrailer = true;
	if (m_pTrailer)
	{
		if (m_dwGTAId && GamePool_Vehicle_GetAt(m_dwGTAId))
		{
			if (m_pTrailer->m_pVehicle)
				ScriptCommand(&detach_trailer_from_cab, m_pTrailer->m_dwGTAId, m_dwGTAId);
		}
	}
}
// 0.3.7
void CVehicle::SetTrailer(CVehicle* pTrailer)
{
	m_pTrailer = pTrailer;
}
// 0.3.7
void CVehicle::LinkToInterior(int iInterior)
{
	if(m_pVehicle)
        m_pVehicle->SetInterior(iInterior);
}

void CVehicle::SetDamageStatus(uint32_t dwPanelDamageStatus, uint32_t dwDoorDamageStatus, uint8_t byteLightDamageStatus)
{

}

void CVehicle::SetTireDamageStatus(uint8_t byteTireDamageStatus)
{

}
// 0.3.7
void CVehicle::RemoveEveryoneFromVehicle()
{
	if (!m_pVehicle) return;
	if (!GamePool_Vehicle_GetAt(m_dwGTAId)) return;

    if (!m_pVehicle) return;
    if(!m_dwGTAId)return;
    if (!GamePool_Vehicle_GetAt(m_dwGTAId)) return;

    if (m_pVehicle->pDriver)
    {
        m_pVehicle->pDriver->RemoveFromVehicle();
    }

    for (int i = 0; i < 7; i++)
    {
        if (m_pVehicle->m_apPassengers[i] != nullptr)
        {
            m_pVehicle->m_apPassengers[i]->RemoveFromVehicle();
        }
    }
}
// 0.3.7
CVehicle* CVehicle::GetTrailer()
{
	if (m_pVehicle)
	{
        CVehicleGTA* pTrailer = m_pVehicle->m_pTrailer;
		if (pTrailer)
		{
			if (pNetGame)
			{
				CVehiclePool* pVehiclePool = pNetGame->GetVehiclePool();
				if (pVehiclePool) {
					VEHICLEID TrailerID = pVehiclePool->FindIDFromGtaPtr(pTrailer);
					if (TrailerID != INVALID_VEHICLE_ID)
					{
						return pVehiclePool->GetAt(TrailerID);
					}
				}
			}
		}
	}

	return nullptr;
}
// 0.3.7
CVehicle* CVehicle::GetTractor()
{
	if (!m_pVehicle) return nullptr;

	int iSubType = ::GetVehicleSubtype(m_pVehicle);
	if (iSubType == VEHICLE_SUBTYPE_BIKE
		|| iSubType == VEHICLE_SUBTYPE_BOAT
		|| iSubType == VEHICLE_SUBTYPE_TRAIN
		|| iSubType == VEHICLE_SUBTYPE_PUSHBIKE)
	{
		return nullptr;
	}

    CVehicleGTA* pTractor = m_pVehicle->m_pTowingVehicle;
	if (pTractor)
	{
		if (pNetGame)
		{
			CVehiclePool* pVehiclePool = pNetGame->GetVehiclePool();
			if (pVehiclePool)
			{
				VEHICLEID TrailerID = pVehiclePool->FindIDFromGtaPtr(pTractor);
				if (TrailerID != INVALID_VEHICLE_ID)
				{
					return pVehiclePool->GetAt(TrailerID);
				}
			}
		}
	}

	return nullptr;
}
// 0.3.7
float CVehicle::GetTrainSpeed()
{
	if (m_pVehicle && m_pVehicle->GetType() == VEHICLE_TYPE_TRAIN) {
		return ((CTrain*)m_pVehicle)->m_fTrainSpeed;
	}
	
	return 0.0f;
}
// 0.3.7 (dword -> word)
uint16_t CVehicle::GetHydraThrusters()
{
	if (m_pVehicle) {
		return ((CAutomobile*)m_pVehicle)->m_nSuspensionHydraulics;
	}

	return 0.0f;
}

bool CVehicle::IsLandingGearNotUp()
{
	if(m_pVehicle && m_pVehicle->GetType() == VEHICLE_TYPE_PLANE)
		return ((CPlane*)m_pVehicle)->m_fLGearAngle != 0.0f;

	return 0;
}

float CVehicle::GetBikeLean()
{
	if (m_pVehicle && GamePool_Vehicle_GetAt(m_dwGTAId) && m_pVehicle->GetType() == VEHICLE_TYPE_BIKE)
		return ((CBike*)m_pVehicle)->m_LeanMatrix.GetPosition().z;

	return 0.0f;
}
// 0.3.7
bool CVehicle::IsATrainPart()
{
	if (m_pVehicle)
	{
		int iModelIndex = m_pVehicle->m_nModelIndex;
		if (iModelIndex == 538 || iModelIndex == 570 || iModelIndex == 537 ||
			iModelIndex == 569 || iModelIndex == 449) {
			return true;
		}
	}

	return false;
}
// 0.3.7
bool CVehicle::VerifyInstance()
{
	return GamePool_Vehicle_GetAt(m_dwGTAId) != nullptr;
}
// 0.3.7
void CVehicle::SetDoorState(int state)
{
	if (state)
	{
		m_pVehicle->m_nDoorLock = (eCarLock)2;
		m_bDoorsLocked = true;
	}
	else
	{
		m_pVehicle->m_nDoorLock =(eCarLock) 0;
		m_bDoorsLocked = false;
	}
}

void CVehicle::SetComponentOpenState(int iDoor, int iComponent, float fDoorOpenRatio)
{
	if (GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
	{
		ScriptCommand(&set_car_door_rotation_to, m_dwGTAId, iDoor, iComponent, fDoorOpenRatio);
	
	}
}

void CVehicle::OpenWindow(uint8_t component)
{
	if (m_pVehicle) {

	}
}

void CVehicle::CloseWindow(uint8_t component)
{
	if (m_pVehicle) {

	}
}
// 0.3.7
void CVehicle::AttachTrailer()
{
	if (m_pTrailer) {
		ScriptCommand(&put_trailer_on_cab, m_pTrailer->m_dwGTAId, m_dwGTAId);
	}
}
// 0.3.7
void CVehicle::RemoveComponent(int iComponentID)
{
	if (!m_pVehicle || !GamePool_Vehicle_GetAt(m_dwGTAId))
		return;

	ScriptCommand(&remove_component, m_dwGTAId, iComponentID);
}
// 0.3.7
void CVehicle::SetZAngle(float fAngle)
{
	if (GamePool_Vehicle_GetAt(m_dwGTAId)) {
		ScriptCommand(&set_car_z_angle, m_dwGTAId, fAngle);
	}
}
// 0.3.7
bool CVehicle::IsDriverLocalPlayer()
{
	if (m_pVehicle && m_pVehicle->pDriver == GamePool_FindPlayerPed())
		return true;

	return false;
}
// 0.3.7
void CVehicle::SetInvulnerable(bool bInv)
{
	if (m_pVehicle && GamePool_Vehicle_GetAt(m_dwGTAId))
	{
		if (bInv)
		{
			ScriptCommand(&set_car_immunities, m_dwGTAId, 1, 1, 1, 1, 1);
			ScriptCommand(&toggle_car_tires_vulnerable, m_dwGTAId, 0);
			m_bIsInvulnerable = true;
		}
		else
		{
			ScriptCommand(&set_car_immunities, m_dwGTAId, 0, 0, 0, 0, 0);
			ScriptCommand(&toggle_car_tires_vulnerable, m_dwGTAId, 1);
			m_bIsInvulnerable = false;
		}
	}
}
// 0.3.7
bool CVehicle::HasSunk()
{
	if (m_pVehicle) {
		return ScriptCommand(&has_car_sunk, m_dwGTAId);
	}

	return false;
}
// 0.3.7
bool CVehicle::HasADriver()
{
	if (m_pVehicle && GamePool_Vehicle_GetAt(m_dwGTAId))
	{
		if (m_pVehicle->pDriver)
		{
			if (m_pVehicle->pDriver->IsInVehicle() &&
				m_pVehicle->pDriver->m_nPedType == (ePedType)0)
				return true;
		}
	}

	return false;
}

void CVehicle::ApplyEngineState(int iState)
{
	if (!m_pVehicle) return;

	m_iEngineState = iState;

    m_pVehicle->m_nVehicleFlags.bEngineOn = iState;
}

void CVehicle::ApplyLightState(int iState)
{
	if (!m_pVehicle)
        return;

	m_bIsLightOn = static_cast<eLightsState>(iState);
    m_pVehicle->m_nVehicleFlags.bLightsOn = iState;
}
// 0.3.7
void CVehicle::ProcessMarkers()
{
	if(!m_pVehicle || !GamePool_Vehicle_GetAt(m_dwGTAId))
		return;

	if(m_byteObjectiveVehicle)
	{
		if(!m_bSpecialMarkerEnabled)
		{
			if(m_dwMarkerID)
			{
				pGame->DisableMarker(m_dwMarkerID);
				m_dwMarkerID = 0;
			}

			ScriptCommand(&tie_marker_to_car, m_dwGTAId, 1, 3, &m_dwMarkerID);
			ScriptCommand(&set_marker_color, m_dwMarkerID, 1006);
			ScriptCommand(&show_on_radar, m_dwMarkerID, 3);

            CHook::CallFunction<void>("_ZN6CRadar16ChangeBlipColourEij", m_dwMarkerID, TranslateColorCodeToRGBA(1006));
			m_bSpecialMarkerEnabled = true;
		}

		return;
	}

	if(m_byteObjectiveVehicle && m_bSpecialMarkerEnabled)
	{
		if(m_dwMarkerID)
		{
			pGame->DisableMarker(m_dwMarkerID);
			m_dwMarkerID = 0;

			m_bSpecialMarkerEnabled = false;
		}
	}

	if(m_pVehicle->GetDistanceFromLocalPlayerPed() < 200.0f && GetTractor() == NULL &&
	   !IsOccupied())
	{
		if(!m_dwMarkerID)
		{
			ScriptCommand(&tie_marker_to_car, m_dwGTAId, 1, 2, &m_dwMarkerID);
			ScriptCommand(&set_marker_color, m_dwMarkerID, 1004);
            CHook::CallFunction<void>("_ZN6CRadar16ChangeBlipColourEij", m_dwMarkerID, TranslateColorCodeToRGBA(1004));
		}
	}

	else if(IsOccupied() || GetTractor() != NULL ||
            m_pVehicle->GetDistanceFromLocalPlayerPed() >= 200.0f)
	{
		if(m_dwMarkerID)
		{
			pGame->DisableMarker(m_dwMarkerID);
			m_dwMarkerID = 0;
		}
	}
}
// 0.3.7
bool CVehicle::IsOccupied()
{
	if (m_pVehicle)
	{
		if (m_pVehicle &&
			(m_pVehicle->m_apPassengers[0] ||
			m_pVehicle->m_apPassengers[1] ||
			m_pVehicle->m_apPassengers[2] ||
			m_pVehicle->m_apPassengers[3] ||
			m_pVehicle->m_apPassengers[4] ||
			m_pVehicle->m_apPassengers[5] ||
			m_pVehicle->m_apPassengers[6])) {
			return true;
		}
	}

	return false;
}

bool CVehicle::IsATowTruck()
{
	if(!m_pVehicle) return false;
	return m_pVehicle->m_nModelIndex == 525;
}

bool CVehicle::IsATrailer()
{
	if(!m_pVehicle) return false;

  	int nModel = m_pVehicle->m_nModelIndex;
	return (nModel == 435 ||
		nModel == 450 || 
		nModel == 584 || 
		nModel == 591 || 
		nModel == 606 || 
		nModel == 607 || 
		nModel == 608 || 
		nModel == 610 || 
		nModel == 611
	);
}

void CVehicle::UpdateDamageStatus(uint32_t dwPanelDamage, uint32_t dwDoorDamage, uint8_t byteLightDamage, uint8_t byteWheelDamage)
{
    if(m_pVehicle)
    {
        if(GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
        {
            Log("UpdateDamageStatus 1");
            if(!dwPanelDamage && !dwDoorDamage && !byteLightDamage)
            {
                if(GetPanelDamageStatus() || GetDoorDamageStatus() || GetLightDamageStatus())
                {
                    // CAutoMobile::Fix
                    Log("UpdateDamageStatus 2");
                    (( void (*)(CVehicleGTA*))(g_libGTASA+(VER_x32 ? 0x55D5C0+1:0x67DF0C)))(m_pVehicle);
                    return;
                }
            }
            Log("UpdateDamageStatus 3");

            SetDoorDamageStatus(dwDoorDamage);
            Log("UpdateDamageStatus 3 1");
            SetPanelDamageStatus(dwPanelDamage);
            Log("UpdateDamageStatus 3 2");
            SetLightDamageStatus(byteLightDamage);

            Log("UpdateDamageStatus 4");
            // CAutomobile::SetupDamageAfterLoad
            (( void (*)(CVehicleGTA*))(g_libGTASA+(VER_x32 ? 0x55D886+1:0x67E368)))(m_pVehicle);
            Log("UpdateDamageStatus 5");
        }
    }
}

void CVehicle::SetPanelDamageStatus(uint32_t dwPanelStatus)
{
    if(m_pVehicle && GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
        ((CAutomobile*)m_pVehicle)->m_nDamageManager.m_nPanelsStatus = dwPanelStatus;
}

uint32_t CVehicle::GetPanelDamageStatus()
{
	if(m_pVehicle && GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
		return ((CAutomobile*)m_pVehicle)->m_nDamageManager.m_nPanelsStatus;

	return 0;
}

void CVehicle::SetDoorDamageStatus(uint32_t dwDoorStatus)
{
	if(m_pVehicle && GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
	{
        ((CAutomobile*)m_pVehicle)->m_nDamageManager.m_aDoorsStatus[0] = static_cast<eDoorStatus>(dwDoorStatus & 7);
        ((CAutomobile*)m_pVehicle)->m_nDamageManager.m_aDoorsStatus[1] = static_cast<eDoorStatus>((dwDoorStatus >> 8) & 7);
        ((CAutomobile*)m_pVehicle)->m_nDamageManager.m_aDoorsStatus[2] = static_cast<eDoorStatus>((dwDoorStatus >> 16) & 7);
        ((CAutomobile*)m_pVehicle)->m_nDamageManager.m_aDoorsStatus[3] = static_cast<eDoorStatus>((dwDoorStatus >> 24) & 7);
	}
}

uint32_t CVehicle::GetDoorDamageStatus()
{
	if(m_pVehicle && GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
	{
		uint32_t dwDoorStatus = (((CAutomobile*)m_pVehicle)->m_nDamageManager.m_aDoorsStatus[0]
                | (((CAutomobile*)m_pVehicle)->m_nDamageManager.m_aDoorsStatus[1] << 8)
                | (((CAutomobile*)m_pVehicle)->m_nDamageManager.m_aDoorsStatus[2] << 16)
                | (((CAutomobile*)m_pVehicle)->m_nDamageManager.m_aDoorsStatus[3] << 24));
		return dwDoorStatus;
	}

	return 0;
}

void CVehicle::SetLightDamageStatus(uint8_t byteLightStatus)
{
	if(m_pVehicle && GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
        ((CAutomobile*)m_pVehicle)->m_nDamageManager.m_nLightsStatus = (uint32_t)byteLightStatus;
}

uint8_t CVehicle::GetLightDamageStatus()
{
	if(m_pVehicle && GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
		return (uint8_t)((CAutomobile*)m_pVehicle)->m_nDamageManager.m_nLightsStatus;

	return 0;
}

void CVehicle::SetWheelPoppedStatus(uint8_t byteWheelStatus)
{
	if(m_pVehicle)
	{
		if(GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
		{
            ((CAutomobile*)m_pVehicle)->m_nDamageManager.m_anWheelsStatus[3] = static_cast<eCarWheelStatus>(byteWheelStatus & 1);
            ((CAutomobile*)m_pVehicle)->m_nDamageManager.m_anWheelsStatus[2] = static_cast<eCarWheelStatus>((byteWheelStatus >> 1) & 1);
            ((CAutomobile*)m_pVehicle)->m_nDamageManager.m_anWheelsStatus[1] = static_cast<eCarWheelStatus>((byteWheelStatus >> 2) & 1);
            ((CAutomobile*)m_pVehicle)->m_nDamageManager.m_anWheelsStatus[0] = static_cast<eCarWheelStatus>((byteWheelStatus >> 3) & 1);
		}
		else if(GetVehicleSubtype() == VEHICLE_SUBTYPE_BIKE)
		{
            ((CBike*)m_pVehicle)->m_nWheelStatus[1] = byteWheelStatus & 1;
            ((CBike*)m_pVehicle)->m_nWheelStatus[0] = (byteWheelStatus >> 1) & 1;
		}
	}
}

uint8_t CVehicle::GetWheelPoppedStatus()
{
	/*if(m_pVehicle)
	{
		if(GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
		{
			uint8_t byteWheelStatus = (m_pVehicle->byteWheelStatus[3] | (m_pVehicle->byteWheelStatus[2] << 1) | (m_pVehicle->byteWheelStatus[1] << 2) | (m_pVehicle->byteWheelStatus[0] << 3));
			return byteWheelStatus;
		}
		else if(GetVehicleSubtype() == VEHICLE_SUBTYPE_BIKE)
		{
			uint8_t byteWheelStatus = (m_pVehicle->byteBikeWheelStatus[1] | (m_pVehicle->byteBikeWheelStatus[0] << 1));
			return byteWheelStatus;
		}
	}*/

	return 0;
}

bool CVehicle::SirenEnabled()
{
	if(!m_pVehicle)
		return m_pVehicle->m_nVehicleFlags.bSirenOrAlarm;

	return false;
}

void CVehicle::EnableSiren(bool bState)
{
	if(!m_pVehicle) return;

	m_pVehicle->m_nVehicleFlags.bSirenOrAlarm = (int)bState;
}

void CVehicle::UpdateColor()
{
	if(m_pVehicle)
	{
		if(m_bHaveColor)
		{
			if(!m_bHasBeenDriven)
			{
				if(m_pVehicle->m_nPrimaryColor != m_byteColor1 || m_pVehicle->m_nSecondaryColor != m_byteColor2)
				{
					m_pVehicle->m_nPrimaryColor = m_byteColor1;
					m_pVehicle->m_nSecondaryColor = m_byteColor2;
				}
			}
		}
	}
}

#include "CCustomPlateManager.h"
void CVehicle::setPlate(ePlateType type, std::string& szNumber, std::string& szRegion)
{

	if(pPlateTexture) {
		RwTextureDestroy(pPlateTexture);
		pPlateTexture = nullptr;
	}

    pPlateTexture = CCustomPlateManager::createTexture(type, szNumber, szRegion);
}

#include "Textures/TextureDatabaseRuntime.h"
void CVehicle::setVinyl(const char* remapName) {
	if(m_pVinylTex) {
        RwTextureDestroy(m_pVinylTex);
        m_pVinylTex = nullptr;
    }
    if (!strcmp(remapName, "empty")) {
        RwTextureDestroy(m_pVinylTex);
        m_pVinylTex = nullptr;

        return;
    }

	m_pVinylTex = TextureDatabaseRuntime::GetTexture(remapName);
}

void CVehicle::processHeadlightsColor(uint8_t& r, uint8_t& g, uint8_t& b) {
	if (GetVehicleSubtype() != VEHICLE_SUBTYPE_CAR) {
		return;
	}

	r = lightColor.r;
	g = lightColor.g;
	b = lightColor.b;
}
void CVehicle::processHeadlightsBeamColor(uint8_t& r, uint8_t& g, uint8_t& b, uint8_t& a) {
	if (GetVehicleSubtype() != VEHICLE_SUBTYPE_CAR) {
		return;
	}

	r = lightColor.r;
	g = lightColor.g;
	b = lightColor.b;
    a = lightColor.a;
}

bool CVehicle::UpdateLastDrivenTime()
{
	if(m_pVehicle)
	{
		if(m_pVehicle->pDriver)
		{
			m_bHasBeenDriven = true;
			m_dwTimeSinceLastDriven = GetTickCount();
			return true;
		}
	}

	return false;
}
#include "Models/ClumpModelInfo.h"
#include "Plugins/NodeNamePlugin/NodeName.h"

void CVehicle::UpdateSteeringWheel()
{
    if (!m_pVehicle) {
        return;
    }

    RpClump *clump = (RpClump*)m_pVehicle->m_pRwObject;
    if (!clump || clump->object.type != rpCLUMP) {
        return;
    }

    RwFrame *outer = CClumpModelInfo::GetFrameFromName(clump, "br_steering");
    if (!outer) {
        return;
    }

    RwFrame *wheel = nullptr;
    for (RwFrame *child = outer->child; child; child = child->next) {
        const RwChar *name = GetFrameNodeName(child);
        if (name && !strcmp(name, "br_steering")) {
            wheel = child;
            break;
        }
    }

    if (!wheel) {
        return;
    }

    const float angle = m_pVehicle->m_fSteerAngle * ms_fSteeringWheelRatio;
    const float c = cosf(angle);
    const float s = sinf(angle);

    RwMatrix *matrix = RwFrameGetMatrix(wheel);
    if (!matrix) {
        return;
    }

    matrix->right = RwV3d{  c, 0.0f, s };
    matrix->up    = RwV3d{ 0.0f, 1.0f, 0.0f };
    matrix->at    = RwV3d{ -s, 0.0f, c };
    matrix->pos   = RwV3d{ 0.0f, 0.0f, 0.0f };
    matrix->flags = 0;

    RwFrameUpdateObjects(wheel);
}

bool CVehicle::GetHandPosition(bool bLeft, CVector &out)
{
    if (!m_pVehicle) {
        return false;
    }

    RpClump *clump = (RpClump*)m_pVehicle->m_pRwObject;
    if (!clump || clump->object.type != rpCLUMP) {
        return false;
    }

    RwFrame *hand = CClumpModelInfo::GetFrameFromName(clump, bLeft ? "LHandPos" : "RHandPos");
    if (!hand) {
        return false;
    }

    RwMatrix *ltm = RwFrameGetLTM(hand);
    if (!ltm) {
        return false;
    }

    out = CVector(ltm->pos.x, ltm->pos.y, ltm->pos.z);
    return true;
}
