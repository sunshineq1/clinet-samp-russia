#pragma once

#include <cstring>
#include "Entity/CVehicleGTA.h"
#include "Enums/ePlateType.h"

enum eTurnState
{
	TURN_OFF,
	TURN_LEFT,
	TURN_RIGHT,
	TURN_ALL
};

enum class eLightsState {
    OFF,
    ON_NEAR,
    HIGH,
};

class CVehicle
{
public:
	CVehicle(int iType, float fX, float fY, float fZ, float fRotation, bool bPreloaded, bool bSiren);
	virtual ~CVehicle();

	int GetVehicleSubtype();
	void AddComponent(int iComponentID);
	void RemoveComponent(int iComponentID);
	void SetPaintJob(uint8_t bytePaintJobID);
	void SetColor(uint8_t iColor1, uint8_t iColor2);
	void LinkToInterior(int iInterior);
	void SetDamageStatus(uint32_t dwPanelDamageStatus, uint32_t dwDoorDamageStatus, uint8_t byteLightDamageStatus);
	void SetTireDamageStatus(uint8_t byteTireDamageStatus);
	void SetPlateText(const char* szPlateText) { strncpy(m_szPlateText, szPlateText, 32); }
	void SetZAngle(float fAngle);
	void ProcessMarkers();
	bool IsOccupied();

	void AttachTrailer();
	void DetachTrailer();
	void SetTrailer(CVehicle* pTrailer);

	bool IsRCVehicle();
	float GetHealth();
	void SetHealth(float fHealth);
	CVehicle* GetTrailer();
	CVehicle* GetTractor();
	float GetTrainSpeed();
	uint16_t GetHydraThrusters();
	float GetBikeLean();
	bool IsATrainPart();
	bool IsATowTruck();
	bool IsATrailer();
	bool VerifyInstance();
	bool IsDriverLocalPlayer();
	void SetInvulnerable(bool bInv);
	bool HasSunk();
	bool HasADriver();

	int GetEngineState() { return m_iEngineState; }

	void ApplyEngineState(int iState);
	void ApplyLightState(int state);

	void SetDoorState(int state);
	void SetComponentOpenState(int iDoor, int iComponent, float fDoorOpenRatio);
	void SetAlarmState(uint16_t wAlarmState) { m_pVehicle->m_nVehicleFlags.bSirenOrAlarm = wAlarmState; }
	void OpenWindow(uint8_t component);
	void CloseWindow(uint8_t component);

	void RemoveEveryoneFromVehicle();

	void UpdateColor();
	bool UpdateLastDrivenTime();

    eTurnState GetTurnLightsState() const;
    void SetTurnLightsState(eTurnState state);

    bool IsTurnBlinkOn() const;

    eTurnState GetTurnLightsBlinkState() const;

    void RenderTurnLights();
    void UpdateSteeringWheel();
    bool GetHandPosition(bool bLeft, CVector &out);
    static inline float ms_fSteeringWheelRatio = 2.6f;
    void DrawTurnlight(bool leftSide);
    void DrawTurnlightPool(const CVector& vecObjOffset, bool bRear, int32 id);
	void DrawRightTurnLight();
	void DrawLeftTurnLight();

    void setPlate(ePlateType type, std::string& szNumber, std::string& szRegion);
    void setVinyl(const char* remapName);
    void processHeadlightsColor(uint8_t& r, uint8_t& g, uint8_t& b);
    void processHeadlightsBeamColor(uint8_t& r, uint8_t& g, uint8_t& b, uint8_t& a);

public:
    CVehicleGTA* m_pVehicle;
	CVehicle* m_pTrailer;
    uintptr 		m_dwGTAId;

    // .. BR Start
	CRGBA       mainColor		    { 0, 0, 0, 255 };
    CRGBA       wheelColor		    { 0, 0, 0, 255 };
	CRGBA       secondColor		    { 0, 0, 0, 255 };
    CRGBA       tonerColor		    { 255, 255, 255, 255 };
    bool        bTonerColorSet       = false;
	CRGBA       lightColor		    { 255, 255, 255, 255 };

    RwTexture*  pPlateTexture       = nullptr;
	RwTexture*  m_pVinylTex 		= nullptr;
    // .. BR End

	bool m_bPreloaded;
	int m_iEngineState;
    eLightsState m_bIsLightOn = eLightsState::OFF;
	bool m_bIsInvulnerable;
	bool m_bIsLocked;
	bool m_bDoorsLocked;
    eTurnState m_iTurnState = TURN_OFF;
    uint32_t m_nTurnStateTime = 0;
	uint8_t m_byteObjectiveVehicle;
	bool m_bSpecialMarkerEnabled;
	uint8_t m_byteColor1;
	uint8_t m_byteColor2;
	bool m_bHaveColor;
	bool m_bSiren;
	char m_szPlateText[32];
	uint32_t m_dwMarkerID;

	void UpdateDamageStatus(uint32_t dwPanelDamage, uint32_t dwDoorDamage, uint8_t byteLightDamage, uint8_t byteWheelDamage);
	void SetPanelDamageStatus(uint32_t dwPanelStatus);
	uint32_t GetPanelDamageStatus();
	void SetDoorDamageStatus(uint32_t dwDoorStatus);
	uint32_t GetDoorDamageStatus();
	void SetLightDamageStatus(uint8_t byteLightStatus);
	uint8_t GetLightDamageStatus();
	void SetWheelPoppedStatus(uint8_t byteWheelStatus);
	uint8_t GetWheelPoppedStatus();

    bool SirenEnabled();

	void EnableSiren(bool bState);

	bool IsLandingGearNotUp();

	bool			m_bHasBeenDriven;
	uint32_t		m_dwTimeSinceLastDriven;\
};