#pragma once

#include "common.h"

struct CPedGTA;

class CVehicleHands
{
public:
    static inline bool  ms_bEnabled = true;
    static inline float ms_fReachLimit = 0.995f;

    static void InjectHooks();
    static void Apply(CPedGTA* pPed);
};
