#pragma once

#define DEBUG_GUI 0

#include "../vendor/encoding/encoding.h"

#include "imguiwrapper.h"
#include "uisettings.h"

#include "widget.h"
#include "widgets/layout.h"
#include "widgets/label.h"
#include "widgets/button.h"
#include "widgets/image.h"
#include "widgets/progressbar.h"
#include "widgets/scrollpanel.h"
#include "widgets/listbox.h"
#include "widgets/editbox.h"

#include "samp_widgets/keyboard.h"
#include "samp_widgets/splashscreen.h"
#include "samp_widgets/chat.h"
#include "samp_widgets/buttonpanel.h"
#include "samp_widgets/playerTabList.h"
#include "samp_widgets/voicebutton.h"

#include "samp_widgets/dialogs/dialog.h"
#include "../net/CObjectPoolDraw.h"

#include "..//vendor/raknet/SingleProducerConsumer.h"

#pragma pack(push, 1)
struct BUFFERED_COMMAND_TEXTDRAW
{
    uint16_t textdrawId;
};
#pragma pack(pop)

class UI : public Widget, public ImGuiWrapper
{
public:
	UI(const ImVec2& display_size, const std::string& font_path);

	bool initialize() override;
	void updateChatAnchor();
	void render() override;
	void shutdown() override;

    ImVec2 m_lastRadarMin = ImVec2(0.0f, 0.0f);
    ImVec2 m_lastRadarMax = ImVec2(0.0f, 0.0f);

    static inline bool m_bObjInfo = false;
    static inline bool m_bCamEditGui = false;
    static inline bool m_bChatGuiDisable = false;
    static inline struct RwTexture* GUIHudRadar = nullptr;

	SplashScreen* splashscreen() const { return m_splashScreen; }
	Chat* chat() const { return m_chat; }
	Keyboard* keyboard() const { return m_keyboard; }
	Dialog* dialog() const { return m_dialog; }
	ButtonPanel* buttonpanel() const { return m_buttonPanel; }
	PlayerTabList* playertablist() const { return m_playerTabList; }
	VoiceButton* voicebutton() const { return m_voiceButton; }

	static const ImColor fixcolor(uint32_t color) {
		return ImColor(
			(int)((color & 0xFF000000) >> 24),
			(int)((color & 0x00FF0000) >> 16),
			(int)((color & 0x0000FF00) >> 8));
	}

	float ScaleX(float x) {
		return x * displaySize().x * (1.0f / 1920.0f);
	}

	float ScaleY(float y) {
		return y * displaySize().y * (1.0f / 1080.0f);
	}

	float GetFontSize() {
		return UISettings::fontSize();
	}

    void loadTxd();

    void RenderPassengerButton();
    static inline struct RwTexture* m_pPassengerButtonTex;

	virtual void touchEvent(const ImVec2& pos, TouchType type) override;

	bool OnTouchEvent(int type, bool multi, int x, int y);

    void renderDebug();
    // Строка сборки вверху экрана: бейдж WN, дата и время сборки, хеш,
    // текущий FPS и занятая стримингом память.
    void renderBuildBanner();

    void ProcessPushedTextdraws();
    void PushToBufferedQueueTextDrawPressed(uint16_t textdrawId);

protected:
	void drawList() override;

private:
	Keyboard* m_keyboard;
	SplashScreen* m_splashScreen;
	Chat* m_chat;
	Dialog* m_dialog;
	ButtonPanel* m_buttonPanel;
	PlayerTabList* m_playerTabList;
	VoiceButton* m_voiceButton;

    CObjectPoolDraw* m_objectDraw;

	Label* label;
    Label* label2;
    Label* label3;
    Label* label4;

	bool m_bNeedClearMousePos = false;

    DataStructures::SingleProducerConsumer<BUFFERED_COMMAND_TEXTDRAW> m_BufferedCommandTextdraws;
};