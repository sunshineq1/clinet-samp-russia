//
// Created by weikton on 05.08.2026.
//

#include "FrameRateFixes.h"
#include "Timer.h"
#include "Entity/CPhysical.h"
#include "Entity/CVehicleGTA.h"
#include "../vendor/armhook/patch.h"

static constexpr float kBaseTimeStep = 50.0f / 30.0f;

static void (*CPhysical__ApplyAirResistance)(CPhysical *self);
static void CPhysical__ApplyAirResistance_hook(CPhysical *self)
{
    if (!self) {
        return;
    }

    if (self->m_fAirResistance <= 0.1f || self->IsVehicle()) {
        float fSpeedMagnitude = self->m_vecMoveSpeed.Magnitude() * self->m_fAirResistance;

        if (CHook::CallFunction<bool>("_ZN10CCullZones29DoExtraAirResistanceForPlayerEv")) {
            if (self->IsVehicle()) {
                auto vehicle = (CVehicleGTA *)self;
                if (vehicle->IsAutomobile() || vehicle->IsSubBike()) {
                    fSpeedMagnitude = 2.5f * fSpeedMagnitude;
                }
            }
        }

        self->m_vecMoveSpeed *= powf(1.0f - fSpeedMagnitude, CTimer::GetTimeStep());
        self->m_vecTurnSpeed *= powf(0.99f, CTimer::ms_fTimeStep / kBaseTimeStep);
    } else {
        const float resistance = powf(self->m_fAirResistance, CTimer::GetTimeStep());
        self->m_vecMoveSpeed *= resistance;
        self->m_vecTurnSpeed *= resistance;
    }
}

static void (*CWaterCannons__Update)();
static void CWaterCannons__Update_hook()
{
    if (!CTimer::IsNewFrame()) {
        return;
    }
    CWaterCannons__Update();
}

static void (*CProjectileInfo__Update)();
static void CProjectileInfo__Update_hook()
{
    if (!CTimer::IsNewFrame()) {
        return;
    }
    CProjectileInfo__Update();
}

static void (*CPlane__PreRender)(void *self);
static void CPlane__PreRender_hook(void *self)
{
    if (!CTimer::IsNewFrame()) {
        return;
    }
    CPlane__PreRender(self);
}

static void (*CWeather__AddRain)();
static void CWeather__AddRain_hook()
{
    if (!CTimer::IsNewFrame()) {
        return;
    }
    CWeather__AddRain();
}

static void (*CVehicle__AddExhaustParticles)(void *self);
static void CVehicle__AddExhaustParticles_hook(void *self)
{
    if (!CTimer::IsNewFrame()) {
        return;
    }

    static uint32_t nextParticleTime = 0;
    if (CTimer::GetTimeInMS() < nextParticleTime) {
        return;
    }
    nextParticleTime = CTimer::GetTimeInMS() + 50;

    CVehicle__AddExhaustParticles(self);
}

static uint32 (*CVehicle__AddWheelDirtAndWater)(void *self, void *colPoint, uint32 produceDrops, uint8 spinning, uint8 inWater);
static uint32 CVehicle__AddWheelDirtAndWater_hook(void *self, void *colPoint, uint32 produceDrops, uint8 spinning, uint8 inWater)
{
    if (!CTimer::IsNewFrame()) {
        return 0;
    }

    static uint32_t nextParticleTime = 0;
    if (CTimer::GetTimeInMS() < nextParticleTime) {
        return 0;
    }
    nextParticleTime = CTimer::GetTimeInMS() + 50;

    return CVehicle__AddWheelDirtAndWater(self, colPoint, produceDrops, spinning, inWater);
}

static float (*CVehicle__ProcessWheelRotation)(void *self, int32 wheelState, const CVector *forward, const CVector *wheelSpeed, float radius);
static float CVehicle__ProcessWheelRotation_hook(void *self, int32 wheelState, const CVector *forward, const CVector *wheelSpeed, float radius)
{
    return CVehicle__ProcessWheelRotation(self, wheelState, forward, wheelSpeed, radius) * CTimer::ms_fTimeStep;
}

static float *g_pHandlingTimeStep = nullptr;

static void (*CVehicle__ProcessWheel)(void *self, CVector &wheelFwd, CVector &wheelRight, CVector &contactSpeed, CVector &contactPoint,
                                      int32 wheelsOnGround, float thrust, float brake, float adhesion, int8 wheelId,
                                      float *wheelSpeed, void *wheelState, uint16 wheelStatus);
static void CVehicle__ProcessWheel_hook(void *self, CVector &wheelFwd, CVector &wheelRight, CVector &contactSpeed, CVector &contactPoint,
                                        int32 wheelsOnGround, float thrust, float brake, float adhesion, int8 wheelId,
                                        float *wheelSpeed, void *wheelState, uint16 wheelStatus)
{
    if (!g_pHandlingTimeStep) {
        CVehicle__ProcessWheel(self, wheelFwd, wheelRight, contactSpeed, contactPoint, wheelsOnGround,
                               thrust, brake, adhesion, wheelId, wheelSpeed, wheelState, wheelStatus);
        return;
    }

    const float saved = *g_pHandlingTimeStep;
    *g_pHandlingTimeStep *= (CTimer::ms_fTimeStep / kBaseTimeStep);
    CVehicle__ProcessWheel(self, wheelFwd, wheelRight, contactSpeed, contactPoint, wheelsOnGround,
                           thrust, brake, adhesion, wheelId, wheelSpeed, wheelState, wheelStatus);
    *g_pHandlingTimeStep = saved;
}

static void (*CVehicle__ProcessBikeWheel)(void *self, CVector &wheelFwd, CVector &wheelRight, CVector &contactSpeed, CVector &contactPoint,
                                          int32 wheelsOnGround, float thrust, float brake, float adhesion, float sideAdhesion,
                                          int8 wheelId, float *wheelSpeed, void *wheelState, int wheelSpecial, uint16 wheelStatus);
static void CVehicle__ProcessBikeWheel_hook(void *self, CVector &wheelFwd, CVector &wheelRight, CVector &contactSpeed, CVector &contactPoint,
                                            int32 wheelsOnGround, float thrust, float brake, float adhesion, float sideAdhesion,
                                            int8 wheelId, float *wheelSpeed, void *wheelState, int wheelSpecial, uint16 wheelStatus)
{
    if (!g_pHandlingTimeStep) {
        CVehicle__ProcessBikeWheel(self, wheelFwd, wheelRight, contactSpeed, contactPoint, wheelsOnGround,
                                   thrust, brake, adhesion, sideAdhesion, wheelId, wheelSpeed, wheelState, wheelSpecial, wheelStatus);
        return;
    }

    const float saved = *g_pHandlingTimeStep;
    *g_pHandlingTimeStep *= (CTimer::ms_fTimeStep / kBaseTimeStep);
    CVehicle__ProcessBikeWheel(self, wheelFwd, wheelRight, contactSpeed, contactPoint, wheelsOnGround,
                               thrust, brake, adhesion, sideAdhesion, wheelId, wheelSpeed, wheelState, wheelSpecial, wheelStatus);
    *g_pHandlingTimeStep = saved;
}

////////////////////////////////////////////////////////////////////////////////
// Задачи, которые внутри считают по ms_fTimeStep и на высоком fps ломаются.

static bool (*CTaskSimpleUseGun__ControlGunMove)(void *self, CVector2D *moveVec);
static bool CTaskSimpleUseGun__ControlGunMove_hook(void *self, CVector2D *moveVec)
{
    const float saved = CTimer::ms_fTimeStep;
    CTimer::ms_fTimeStep = kBaseTimeStep;
    const bool result = CTaskSimpleUseGun__ControlGunMove(self, moveVec);
    CTimer::ms_fTimeStep = saved;
    return result;
}

static bool (*ClimbProcessPed)(void *self, void *ped);
static bool ClimbProcessPed_hook(void *self, void *ped)
{
    const float saved = CTimer::ms_fTimeStep;
    CTimer::ms_fTimeStep = kBaseTimeStep;
    const bool result = ClimbProcessPed(self, ped);
    CTimer::ms_fTimeStep = saved;
    return result;
}

void CFrameRateFixes::InjectHooks()
{
    SET_TO(g_pHandlingTimeStep, (*(uintptr_t *)(g_libGTASA + (VER_x32 ? 0x6777C0 : 0x84CFB8))) + 4);

    CHook::InlineHook("_ZN9CPhysical18ApplyAirResistanceEv", &CPhysical__ApplyAirResistance_hook, &CPhysical__ApplyAirResistance);
    CHook::InlineHook("_ZN13CWaterCannons6UpdateEv", &CWaterCannons__Update_hook, &CWaterCannons__Update);
    CHook::InlineHook("_ZN15CProjectileInfo6UpdateEv", &CProjectileInfo__Update_hook, &CProjectileInfo__Update);
    CHook::InlineHook("_ZN6CPlane9PreRenderEv", &CPlane__PreRender_hook, &CPlane__PreRender);
    CHook::InlineHook("_ZN8CWeather7AddRainEv", &CWeather__AddRain_hook, &CWeather__AddRain);
    CHook::InlineHook("_ZN8CVehicle19AddExhaustParticlesEv", &CVehicle__AddExhaustParticles_hook, &CVehicle__AddExhaustParticles);

    CHook::InlineHook("_ZN8CVehicle20ProcessWheelRotationE11tWheelStateRK7CVectorS3_f",
                      &CVehicle__ProcessWheelRotation_hook, &CVehicle__ProcessWheelRotation);
    CHook::InlineHook("_ZN8CVehicle20AddWheelDirtAndWaterER9CColPointjhh",
                      &CVehicle__AddWheelDirtAndWater_hook, &CVehicle__AddWheelDirtAndWater);

    CHook::InlineHook("_ZN17CTaskSimpleUseGun14ControlGunMoveEP9CVector2D",
                      &CTaskSimpleUseGun__ControlGunMove_hook, &CTaskSimpleUseGun__ControlGunMove);

    CHook::InstallPLT(g_libGTASA + (VER_x32 ? 0x66FC80 : 0x83FE78), &CVehicle__ProcessWheel_hook, &CVehicle__ProcessWheel);
    CHook::InstallPLT(g_libGTASA + (VER_x32 ? 0x673F34 : 0x846A90), &CVehicle__ProcessBikeWheel_hook, &CVehicle__ProcessBikeWheel);
    CHook::InstallPLT(g_libGTASA + (VER_x32 ? 0x66CC18 : 0x83A6A0), &ClimbProcessPed_hook, &ClimbProcessPed);
}
