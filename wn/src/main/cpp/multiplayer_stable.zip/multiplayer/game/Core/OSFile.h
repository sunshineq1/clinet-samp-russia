//
// Created by weikton on 20.11.2023.
//

#pragma once

typedef void *OSFile;

